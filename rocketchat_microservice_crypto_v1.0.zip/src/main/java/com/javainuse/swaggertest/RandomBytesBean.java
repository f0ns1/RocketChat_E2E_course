package com.javainuse.swaggertest;

public class RandomBytesBean {

    public String size = null;

    //getters && setters
    public String getSize(){
        return this.size;
    }
    public void setSize(String size){
        this.size = size;
    }
    
}
